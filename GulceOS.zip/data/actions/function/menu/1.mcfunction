$dialog show $(Selector)[$(Unless)] actions:gui
