$clear $(player) $(item) $(count)
