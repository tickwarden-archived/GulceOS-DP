$tag $(player) add reallyfreezed
